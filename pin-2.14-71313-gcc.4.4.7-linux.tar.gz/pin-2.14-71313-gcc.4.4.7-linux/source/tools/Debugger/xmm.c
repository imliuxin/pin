/*NO LEGAL*/


extern void DoXmm();
extern void ZeroXmms();

int main()
{
    ZeroXmms();
    DoXmm();
    return 0;
}
